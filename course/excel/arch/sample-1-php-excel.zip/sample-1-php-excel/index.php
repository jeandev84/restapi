<?php

set_include_path(__DIR__);
require 'vendor/autoload.php';

$obj = new Excphp();

$obj->genDoc();