<?php

Route::get('/sitemap.xml',[
    'controller' => 'SitemapController',
    'action'     => 'show'
]);
