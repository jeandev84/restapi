<?php
return [
    'name'        => 'SEO Pack',
    'description' => ''
];