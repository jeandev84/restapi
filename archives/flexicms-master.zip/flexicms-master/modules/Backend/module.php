<?php

return [
    'name'        => 'Backend',
    'description' => ''
];
