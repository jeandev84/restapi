<?php
namespace Modules\Frontend\Classes;

/**
 * Class Widget
 * @package Modules\Frontend\Classes
 */
class Widget
{
    public static function get(string $name)
    {
    }
}
