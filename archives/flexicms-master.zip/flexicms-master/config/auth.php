<?php

return [
    'username' => 'admin@flexicms.ru',
    'password'  => '1111'
];