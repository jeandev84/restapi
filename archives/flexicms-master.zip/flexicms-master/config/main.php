<?php

return [
    'base_url'         => '//' . $_SERVER['HTTP_HOST'],
    'default_lang'     => 'ru',
    'default_timezone' => 'America/Chicago',
    'default_theme'    => 'default'
];
