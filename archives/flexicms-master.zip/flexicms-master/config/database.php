<?php

return [
    'host'     => '127.0.0.1',
    'db_name'  => 'flexicms',
    'username' => 'root',
    'password' => '',
    'charset'  => 'utf8',
    'driver'   => 'mysql'
];
