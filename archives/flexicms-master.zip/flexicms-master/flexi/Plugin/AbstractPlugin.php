<?php
namespace Flexi\Plugin;

/**
 * Class AbstractPlugin
 * @package Flexi\Plugin
 */
abstract class AbstractPlugin
{
}
