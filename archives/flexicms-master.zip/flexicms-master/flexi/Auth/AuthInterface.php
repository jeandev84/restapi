<?php
namespace Flexi\Auth;

/**
 * Interface AuthInterface
 * @package Flexi\Auth
 */
interface AuthInterface
{}
