<?php
namespace Flexi\Http;

class Response
{}
