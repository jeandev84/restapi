<?php
/**
 * This file is part of the FlexiCMS (https://flexicms.org)
 * Copyright (c) 2017 Artem Melnik (https://artemmelnik.com)
 */

declare(strict_types=1);

namespace Flexi\Routing;

use Flexi\Http\Uri;

/**
 * Class GenerateUri
 * @package Flexi\Routing
 */
class GenerateUri
{
}
