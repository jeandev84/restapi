<?php
namespace Flexi\Orm\Behaviour;

class Encoded
{}
