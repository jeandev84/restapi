<?php
namespace Flexi\Orm;

class Pagination
{}
