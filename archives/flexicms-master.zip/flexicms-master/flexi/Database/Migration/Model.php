<?php
namespace Flexi\Database\Migration;

/**
 * Class Model
 * @package Flexi\Database\Migration
 */
class Model extends \Flexi\Orm\Model
{
    /**
     * @var  string  Table name
     */
    protected static $table = 'migrations';
}
