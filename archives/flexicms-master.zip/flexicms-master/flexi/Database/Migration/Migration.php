<?php
namespace Flexi\Database\Migration;

/**
 * Class Migration
 * @package Flexi\Database\Migration
 */
class Migration
{}
