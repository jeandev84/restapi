<?php
namespace Flexi\Database;

class Seed
{}
