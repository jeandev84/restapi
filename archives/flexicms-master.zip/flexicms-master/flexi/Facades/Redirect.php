<?php
namespace Flexi\Facades;

use Flexi\Http\Redirect as Factory;

class Redirect
{}
