<?php
namespace Flexi\CustomField;

/**
 * Class ValidationParams
 * @package Flexi\CustomField
 */
class ValidationParams
{
    public static function isValidation(Params\CustomFieldParams $params)
    {
    }
}
