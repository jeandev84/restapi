<?php

namespace App\Exception;

use Exception;

class DeprecatedApiException extends Exception
{
}
