# Репозиторий с примерами кода для курса [Symfony Framework](https://otus.ru/lessons/symfony/)

Группа: Symfony-2023-02

Автор: [Михаил Каморин](mailto:m.v.kamorin@gmail.com)
