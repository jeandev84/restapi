<?php

class TokenExpiredException extends Exception
{
}