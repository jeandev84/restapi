<!DOCTYPE html>
<html>
<head>
	<title>404 page not found!</title>
</head>
<body>
   <h1>404 Page not found!</h1>
   <p>Something, went wrong!</p>
   <!--  -->
</body>
</html>