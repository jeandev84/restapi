<?php 
namespace JK\ORM\Exceptions;

/**
 * @package JK\ORM\Exceptions\QueryException
*/ 
class QueryException extends \Exception {}