<?php 
namespace JK\ORM\Exceptions;

/**
 * @package JK\ORM\Exceptions\ConnectionException
*/ 
class ConnectionException extends \Exception {}