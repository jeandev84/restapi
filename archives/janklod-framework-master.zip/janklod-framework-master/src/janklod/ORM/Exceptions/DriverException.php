<?php 
namespace JK\ORM\Exceptions;

/**
 * @package JK\ORM\Exceptions\DriverException
*/ 
class DriverException extends ConnectionException {}