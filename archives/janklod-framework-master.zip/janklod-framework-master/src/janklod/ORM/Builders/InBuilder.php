<?php 
namespace JK\ORM\Builders;


/**
 * @package 
*/ 
class InBuilder extends CustomBuilder
{
     
     /**
      * Build conditions
      * @return string
     */
     public function build()
     {
     	 
     }


}