<?php 
namespace JK\ORM\Drivers;


use \PDO;

/**
 * @package JK\ORM\Drivers\OracleDriver
*/
class OracleDriver extends CustomDriver
{
     
/**
* Connect  to PDO 
* @return \PDO
*/
public function connect()
{

}

/**
* Get DSN
* @return string
*/
public function dsn()
{
 
}
}