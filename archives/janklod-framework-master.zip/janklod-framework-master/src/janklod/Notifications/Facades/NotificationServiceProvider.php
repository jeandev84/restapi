<?php 
namespace JK\Notifications\Facades;

use JK\DI\ServiceProvider;
use JK\Notifications\Notification;

/**
 * @package JK\Notifications\Facades\NotificationServiceProvider 
*/ 
class NotificationServiceProvider extends ServiceProvider
{
        
/**
 * Register service
 * @return void
*/
public function register()
{
    
}
}