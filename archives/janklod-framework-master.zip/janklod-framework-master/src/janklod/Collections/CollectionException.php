<?php 
namespace JK\Collections;

/**
 * @package JK\Collections\CollectionException 
**/
class CollectionException extends \Exception {}