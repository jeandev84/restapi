<?php 
namespace JK\Security\Authentication;



/**
 * @package JK\Security\Authentication\DatabaseAuth
*/ 
class DatabaseAuth implements AuthInterface {}
