<?php 
namespace JK\DI\Registers;


use JK\DI\Contracts\RegistrableInterface;


/**
 * @package JK\DI\Registers\CustomRegister
*/ 
abstract class CustomRegister 
implements RegistrableInterface {}