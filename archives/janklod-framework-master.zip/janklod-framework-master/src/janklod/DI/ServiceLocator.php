<?php 
namespace JK\DI;


/**
 * @package JK\DI\ServiceLocator 
*/ 
class ServiceLocator {}