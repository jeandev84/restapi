<?php 
namespace JK\Container\Exceptions;

/**
 * @package JK\Container\Exceptions\ContainerException
*/ 
class ContainerException extends \Exception {}