<?php 
namespace JK\Routing;

/**
 * @package JK\Routing\RouterException 
*/ 
class RouterException extends \Exception {}