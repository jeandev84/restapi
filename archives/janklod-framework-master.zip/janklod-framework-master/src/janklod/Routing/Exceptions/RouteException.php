<?php 
namespace JK\Routing\Exceptions;

/**
 * @package JK\Routing\Exceptions\RouteException
*/ 
class RouteException extends \Exception {}