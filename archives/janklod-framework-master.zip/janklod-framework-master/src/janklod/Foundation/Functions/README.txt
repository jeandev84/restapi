
$posts = [
'name' => 'Jean Claude',
'username' => 'Brown',
'password' => 'xxxx'
];   

debug($posts);

echo base_url().'/admin'; 
 