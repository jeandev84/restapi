<?php 
namespace JK\Library;


/**
 * @package JK\Library\Pagination 
*/ 
class Pagination 
{

	
}