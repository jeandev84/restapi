<?php 
namespace JK\Library\Caching;

/**
 * @package JK\Library\Caching\CacheInterface 
*/ 
interface CacheInterface 
{
	
}