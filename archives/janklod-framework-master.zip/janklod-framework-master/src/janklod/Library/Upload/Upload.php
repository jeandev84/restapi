<?php 
namespace JK\Library;


/**
 * @package JK\Library\Upload 
*/ 
class Upload 
{

	
}