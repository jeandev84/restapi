<?php 
namespace JK\FileSystem\Exceptions;

/**
 * @package JK\FileSystem\Exceptions\FileCacheException 
*/ 
class FileCacheInterface extends \Exception {}