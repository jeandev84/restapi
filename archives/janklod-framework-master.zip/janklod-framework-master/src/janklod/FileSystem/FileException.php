<?php 
namespace JK\FileSystem;

/**
 * @package JK\FileSystem\FileException 
*/ 
class FileException extends \Exception {}