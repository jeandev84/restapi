<?php 
namespace JK\CacheSystem\Exceptions;

/**
 * @package JK\CacheSystem\Exceptions\ApcCacheException 
*/ 
class ApcCacheInterface extends \Exception {}