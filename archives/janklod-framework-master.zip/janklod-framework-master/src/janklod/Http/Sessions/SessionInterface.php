<?php 
namespace JK\Http\Sessions;

/**
 * @package JK\Http\Sessions\SessionInterface 
*/ 
interface SessionInterface
{
	
}