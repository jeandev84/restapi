<?php 
namespace JK\View\Extension;


/**
 * @package JK\View\Extensions\PHPExtension
*/
class PHPExtension {}
