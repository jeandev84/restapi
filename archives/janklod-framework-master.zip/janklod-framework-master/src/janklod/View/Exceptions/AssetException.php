<?php 
namespace JK\View\Exceptions;

/**
 * @package JK\View\Exceptions\AssetException 
*/ 
class AssetException extends \Exception {}