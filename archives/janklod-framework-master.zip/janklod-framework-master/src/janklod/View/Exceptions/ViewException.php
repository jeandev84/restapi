<?php 
namespace JK\View\Exceptions;

/**
 * @package JK\View\Exceptions\ViewException 
*/ 
class ViewException extends \Exception {}