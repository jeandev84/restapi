<?php 
namespace JK\Loader;


/**
 * @package JK\Loader\LoadException 
*/
class LoadException extends \Exception {}