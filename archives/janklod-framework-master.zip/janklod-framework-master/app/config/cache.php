<?php 

return [

   /*
    |------------------------------------------------------------------
    |   Define your cache directory
    |   By default all cache will be stored inside file 'temp/framework/cache'
    |   But you can to define your's directory [ex: app/cache ]
    |------------------------------------------------------------------
   */
    'cache_dir' => '',
   
];


