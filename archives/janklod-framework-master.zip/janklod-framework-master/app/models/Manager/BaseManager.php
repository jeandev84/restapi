<?php 
namespace app\models\Manager;


use JK\Database\Model;
use \PDO;



/**
 * @package app\models\Manager\BaseManager 
*/ 
class BaseManager extends Model
{
    
/**
* Constructor
* 
* @return void
*/
public function __construct()
{
   parent::__construct();
}

}