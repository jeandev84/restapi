<div style="margin-top: 30px;">
    <div class="row">
      <div class="col-md-12">
         <h1 style="font-size: 5em;">404 ошибка!</h1>
         <h3>Страница не найдена</h3>
         <small>Опаа! что то пошло не так!((</small>
         <div>
         	<a href="/"><small>на главную</small></a>
         </div>
       </div>
      </div>
</div>