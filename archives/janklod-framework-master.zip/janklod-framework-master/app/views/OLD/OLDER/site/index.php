
<?php // Asset::css('test') ?>
<div class="text-center">
	<h1>Welcome to JK Framework</h1>
</div>
<?php // Asset::js('test') ?>