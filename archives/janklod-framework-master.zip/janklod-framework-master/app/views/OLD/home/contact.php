<div class="row">
	<div class="col-md-6">
		<form action="" method="POST">
			<div class="form-group">
				<input type="text" name="username" class="form-control" placeholder="Username">
			</div>
			<div class="form-group">
				<input type="text" name="password" class="form-control" placeholder="Password">
			</div>
			<!--
			<div class="form-group">
				<input type="text" name="role" class="form-control" placeholder="Role">
			</div>
		    -->
			<button type="submit" class="btn btn-primary">Send</button>
        </form>
	</div>
</div>