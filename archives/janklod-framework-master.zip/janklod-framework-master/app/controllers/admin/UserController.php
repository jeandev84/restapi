<?php 
namespace app\controllers\admin;


/**
 * @package app\controllers\admin\UserController 
*/
class UserController 
{
	   
}