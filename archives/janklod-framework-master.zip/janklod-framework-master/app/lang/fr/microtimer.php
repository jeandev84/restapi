<?php 

return [
  'msg' => 'Page generee en <b>%s</b> ms'
];