<?php 


return [
 'msg' => 'Страница сгенирована в <b>%s</b> ms'
];