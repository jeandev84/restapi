<?php 
return [
 'username'    => 'имя пользователя',
 'is required' => 'объязательно',
 'email'       => 'e-майл',
 'text'        => 'текст',
 'already'     => 'уже',
 'exists'      => 'существует',
 'password'    => 'пароль',
 'minimum of'  => 'минимум',
 'maximum of'  => 'максимум',
 'must be a'   => 'должен быть',
 'characters'  => 'симбол(а/ов)',
 'must match'  => 'должен совпасть'
];