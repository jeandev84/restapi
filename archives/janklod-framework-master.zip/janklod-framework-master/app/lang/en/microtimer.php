<?php 

return [
 'msg' => 'Page generated in <b>%s</b> ms'
];