# PSR-0 Meta Document

## 1. Summary

PSR-0 predates the official FIG structure and describes a standard for 
autoloader interoperability. It is superseded by PSR-4. This meta document
was added after the PSR has been deprecated. 

## 2. People

### 2.1 Editor

* Matthew Weier O'Phinney

