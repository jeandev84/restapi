# PSR-1 Meta Document

## 1. Summary

This section of the standard comprises what should be considered the standard
coding elements that are required to ensure a high level of technical
interoperability between shared PHP code. This meta document is added after the
document was accepted. 

## 2. People

### 2.1 Editor

* Paul M. Jones

