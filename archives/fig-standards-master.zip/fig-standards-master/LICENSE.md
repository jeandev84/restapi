# License

Unless stated otherwise, all content is licensed under the Creative Commons
Attribution License and code licensed under the MIT License.

Copies of all licenses are included in this project's root directory.