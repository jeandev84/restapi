<?php

echo "Hello world";