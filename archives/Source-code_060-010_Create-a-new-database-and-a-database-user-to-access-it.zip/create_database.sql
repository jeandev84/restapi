CREATE DATABASE api_db;

GRANT ALL PRIVILEGES ON api_db.* TO api_db_user@localhost IDENTIFIED BY 'k5cWTeqs6GXK2hzF';
