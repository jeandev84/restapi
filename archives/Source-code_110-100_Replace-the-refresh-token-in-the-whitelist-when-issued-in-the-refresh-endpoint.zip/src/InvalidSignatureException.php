<?php

class InvalidSignatureException extends Exception
{
}